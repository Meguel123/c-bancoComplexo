﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MySql.Data.MySqlClient;
using System.Data;

namespace estudos
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        MySqlConnection connection = new MySqlConnection();
        MySqlCommand command = new MySqlCommand();

        private void button1_Click(object sender, EventArgs e)
        {


            Form4 men = new Form4();
            this.Hide();
            men.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;User Id=root;database=db_musical;password=miguel1930;";
            string query = "select m.nm_musica , c.nm_cantor\r\nfrom tb_musica as m\r\ninner join tb_album as a\r\non m.fk_id_album = a.id_album\r\ninner join tb_cantor as c\r\non a.fk_id_cantor = c.id_cantor;";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    MySqlDataAdapter da = new MySqlDataAdapter(query, connection);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;


                }

                catch 
                {
                    

                }

            }
        }
    }
}
