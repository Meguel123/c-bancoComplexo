namespace estudos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            Form4   men = new Form4();
            this.Hide();
            men.ShowDialog();
        }
    }
}
