﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace estudos
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            Form1 art = new Form1();
            this.Hide();
            art.ShowDialog();

        }

        private void button2_Click(object sender, EventArgs e)
        {

            Form2 mus = new Form2();
            this.Hide();
            mus.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            Form3 al = new Form3();
            this.Hide();
            al.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form5 men = new Form5();
            this.Hide();
            men.ShowDialog();
        }
    }
}
