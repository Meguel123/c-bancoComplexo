﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MySql.Data.MySqlClient;
using System.Data;
namespace estudos
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        MySqlConnection connection = new MySqlConnection();
        MySqlCommand command = new MySqlCommand();

        private void button1_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            this.Hide();
            form4 = new Form4();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;User Id=root;database=db_musical;password=miguel1930;";
            string query = "SELECT * FROM tb_cantor";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    MySqlDataAdapter da = new MySqlDataAdapter(query, connection);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;
                }


                catch
                {
                    MessageBox.Show("erro");

                }
            }
        }
    }
    }
