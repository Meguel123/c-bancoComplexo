Create database db_musical;
use db_musical;

create table tb_cantor(
id_cantor int auto_increment primary key,
nm_cantor varchar(45)
);

create table tb_album(
id_album int auto_increment primary key,
nm_album varchar(45),
fk_id_cantor int,
foreign key (fk_id_cantor) references tb_cantor (id_cantor)
);

create table tb_musica(
id_musica int auto_increment primary key,
nm_musica varchar(45),
fk_id_album int,
foreign key (fk_id_album) references tb_album (id_album)
);

INSERT INTO tb_cantor (nm_cantor) VALUES ('Adele');
-- id_cantor = 1
INSERT INTO tb_album (nm_album, fk_id_cantor) VALUES 
  ('19', 1), ('21', 1), ('25', 1);
-- Supondo id_album = 1,2,3
INSERT INTO tb_musica (nm_musica, fk_id_album) VALUES
-- 19
  ('Daydreamer', 1),
  ('Best for Last', 1),
  ('Chasing Pavements', 1),
  ('Cold Shoulder', 1),
  ('Crazy for You', 1),
  ('Melt My Heart to Stone', 1),
  ('First Love', 1),
  ('Right as Rain', 1),
  ('Make You Feel My Love', 1),
  ('My Same', 1),
  ('Tired', 1),
  ('Hometown Glory', 1),
-- 21
  ('Rolling in the Deep', 2),
  ('Rumour Has It', 2),
  ('Turning Tables', 2),
  ('Don’t You Remember', 2),
  ('Set Fire to the Rain', 2),
  ('He Won’t Go', 2),
  ('Take It All', 2),
  ('I’ll Be Waiting', 2),
  ('One and Only', 2),
  ('Lovesong', 2),
  ('Someone Like You', 2),
-- 25
  ('Hello', 3),
  ('Send My Love (To Your New Lover)', 3),
  ('I Miss You', 3),
  ('When We Were Young', 3),
  ('Remedy', 3),
  ('Water Under the Bridge', 3),
  ('River Lea', 3),
  ('Love in the Dark', 3),
  ('Million Years Ago', 3),
  ('All I Ask', 3),
  ('Sweetest Devotion', 3);

INSERT INTO tb_cantor (nm_cantor) VALUES ('Nirvana');
-- id_cantor = 2
INSERT INTO tb_album (nm_album, fk_id_cantor) VALUES 
  ('Bleach', 2), ('Nevermind', 2), ('In Utero', 2);
-- Supondo id_album = 4,5,6
INSERT INTO
 tb_musica (nm_musica, fk_id_album) VALUES
-- Bleach
  ('Blew', 4),
  ('Floyd the Barber', 4),
  ('About a Girl', 4),
  ('School', 4),
  ('Love Buzz', 4),
  ('Paper Cuts', 4),
  ('Negative Creep', 4),
  ('Scoff', 4),
  ('Swap Meet', 4),
  ('Mr. Moustache', 4),
  ('Sifting', 4),
  ('Big Cheese', 4),
  ('Downer', 4),
-- Nevermind
  ('Smells Like Teen Spirit', 5),
  ('In Bloom', 5),
  ('Come as You Are', 5),
  ('Breed', 5),
  ('Lithium', 5),
-- In Utero
  ('Heart-Shaped Box', 6),
  ('Rape Me', 6),
  ('All Apologies', 6);

INSERT INTO tb_cantor (nm_cantor) VALUES ('Aaliyah');
-- id_cantor = 3
INSERT INTO tb_album (nm_album, fk_id_cantor) VALUES
  ('Age Ain’t Nothing But a Number', 3),
  ('One in a Million', 3),
  ('Aaliyah', 3);
-- id_album = 7,8,9
INSERT INTO tb_musica (nm_musica, fk_id_album) VALUES
  ('Back & Forth', 7),
  ('At Your Best (You Are Love)', 7),
  ('One in a Million', 8),
  ('If Your Girl Only Knew', 8),
  ('Try Again', 9),
  ('More Than a Woman', 9);

INSERT INTO tb_cantor (nm_cantor) VALUES ('The Jimi Hendrix Experience');
-- id_cantor = 4
INSERT INTO tb_album (nm_album, fk_id_cantor) VALUES
  ('Are You Experienced', 4),
  ('Axis: Bold as Love', 4),
  ('Electric Ladyland', 4);
-- id_album =10,11,12
INSERT INTO tb_musica (nm_musica, fk_id_album) VALUES
  ('Purple Haze', 10),
  ('Manic Depression', 10),
  ('Little Wing', 11),
 ('If 6 Was 9', 11),
  ('Voodoo Child (Slight Return)', 12),
  ('All Along the Watchtower', 12);

INSERT INTO tb_cantor (nm_cantor) VALUES ('Buffalo Springfield');
-- id_cantor = 5
INSERT INTO tb_album (nm_album, fk_id_cantor) VALUES
  ('Buffalo Springfield', 5),
  ('Buffalo Springfield Again', 5),
  ('Last Time Around', 5);
-- id_album =13,14,15
INSERT INTO tb_musica (nm_musica, fk_id_album) VALUES
  ('For What It’s Worth', 13),
  ('Mr. Soul', 14),
  ('Expecting to Fly', 14),
  ('Broken Arrow', 14),
  ('Kind Woman', 15);

INSERT INTO tb_cantor (nm_cantor) VALUES ('Blind Melon');
-- id_cantor = 6
INSERT INTO tb_album (nm_album, fk_id_cantor) VALUES
  ('Blind Melon', 6),
  ('Soup', 6),
  ('For My Friends', 6);
-- id_album =16,17,18
INSERT INTO tb_musica (nm_musica, fk_id_album) VALUES
  ('No Rain', 16),
  ('Tones of Home', 17),
  ('Change', 17),
  ('Galaxie', 17),
  ('The Sippin\' Song', 18);

INSERT INTO tb_cantor (nm_cantor) VALUES ('Camp Cope');
-- id_cantor = 7
INSERT INTO tb_album (nm_album, fk_id_cantor) VALUES
  ('Camp Cope', 7),
  ('How to Socialise & Make Friends', 7),
  ('Running with the Hurricane', 7);
-- id_album =19,20,21
INSERT INTO tb_musica (nm_musica, fk_id_album) VALUES
  ('Jet Fuel Can’t Melt Steel Beams', 19),
  ('The Opener', 20),
  ('Jealous', 21),
  ('Running with the Hurricane', 21);

INSERT INTO tb_cantor (nm_cantor) VALUES ('Lush');
-- id_cantor = 8
INSERT INTO tb_album (nm_album, fk_id_cantor) VALUES
  ('Spooky', 8),
  ('Split', 8),
  ('Lovelife', 8);
-- id_album =22,23,24
INSERT INTO tb_musica (nm_musica, fk_id_album) VALUES
  ('Nothing Natural', 22),
  ('Ladykillers', 23),
  ('Single Girl', 24),
  ('Heavenly Nobodies', 24);

INSERT INTO tb_cantor (nm_cantor) VALUES ('The Idle Race');
-- id_cantor = 9
INSERT INTO tb_album (nm_album, fk_id_cantor) VALUES
  ('The Birthday Party', 9),
  ('The Idle Race', 9),
  ('Time Is', 9);
-- id_album =25,26,27
INSERT INTO tb_musica (nm_musica, fk_id_album) VALUES
  ('The Birthday Party', 25),
  ('Morning Rain', 25),
  ('Come with Me', 26),
  ('Girl at the Window', 26),
  ('Time Is', 27);

INSERT INTO tb_cantor (nm_cantor) VALUES ('The English Beat');
-- id_cantor = 10
INSERT INTO tb_album (nm_album, fk_id_cantor) VALUES
  ('I Just Can’t Stop It', 10),
  ('Wha’ppen?', 10),
  ('Special Beat Service', 10);
-- id_album =28,29,30
INSERT INTO tb_musica (nm_musica, fk_id_album) VALUES
  ('Mirror in the Bathroom', 28),
  ('Best Friend', 28),
  ('Save It for Later', 30);

INSERT INTO tb_cantor (nm_cantor) VALUES ('American Football');
-- id_cantor = 11
INSERT INTO tb_album (nm_album, fk_id_cantor) VALUES
  ('American Football (LP1)', 11),
  ('LP2', 11),
  ('LP3', 11);
-- id_album =31,32,33
INSERT INTO tb_musica (nm_musica, fk_id_album) VALUES
  ('Never Meant', 31),
  ('Stay Home', 31),
  ('Silhouettes', 33),
  ('Uncomfortably Numb', 33);

INSERT INTO tb_cantor (nm_cantor) VALUES ('Beyoncé');
-- id_cantor = 12
INSERT INTO tb_album (nm_album, fk_id_cantor) VALUES
  ('B’Day', 12),
  ('Beyoncé', 12),
  ('Lemonade', 12);
-- id_album =34,35,36
INSERT INTO tb_musica (nm_musica, fk_id_album) VALUES
  ('Irreplaceable', 34),
  ('Deja Vu', 34),
  ('Single Ladies (Put a Ring on It)', 35),
  ('Drunk in Love', 35),
  ('Formation', 36),
  ('Sorry', 36);

INSERT INTO tb_cantor (nm_cantor) VALUES ('Queen');
-- id_cantor = 13
INSERT INTO tb_album (nm_album, fk_id_cantor) VALUES
  ('Queen', 13),
  ('News of the World', 13),
  ('The Game', 13);
-- id_album =37,38,39
INSERT INTO tb_musica (nm_musica, fk_id_album) VALUES
  ('Keep Yourself Alive', 37),
  ('Bohemian Rhapsody', 38),
  ('We Will Rock You', 38),
  ('Another One Bites the Dust', 39);

INSERT INTO tb_cantor (nm_cantor) VALUES ('Metallica');
-- id_cantor = 14
INSERT INTO tb_album (nm_album, fk_id_cantor) VALUES
  ('Kill ’Em All', 14),
  ('Master of Puppets', 14),
  ('…And Justice for All', 14);
-- id_album =40,41,42
INSERT INTO tb_musica (nm_musica, fk_id_album) VALUES
  ('Seek & Destroy', 40),
  ('Whiplash', 40),
  ('Master of Puppets', 41),
  ('Battery', 41),
  ('One', 42);

INSERT INTO tb_cantor (nm_cantor) VALUES ('The Beatles');
-- id_cantor = 15
INSERT INTO tb_album (nm_album, fk_id_cantor) VALUES
  ('Abbey Road', 15),
  ('Sgt. Pepper’s Lonely Hearts Club Band', 15),
  ('Revolver', 15);
-- id_album =43,44,45
INSERT INTO tb_musica (nm_musica, fk_id_album) VALUES
  ('Come Together', 43),
  ('Here Comes the Sun', 43),
  ('Lucy in the Sky with Diamonds', 44),
  ('Eleanor Rigby', 44),
  ('Here, There and Everywhere', 45),
  ('Good Day Sunshine', 45);
  
select m.nm_musica , c.nm_cantor
from tb_musica as m
inner join tb_album as a
on m.fk_id_album = a.id_album
inner join tb_cantor as c
on a.fk_id_cantor = c.id_cantor;
  
select a.nm_album, c.nm_cantor
from tb_album as a
inner join tb_cantor as c
on a.fk_id_cantor = c.id_cantor;



